function mostrar()
{
  alert("dos");
}
